var s_sta = document.getElementById('s_sta'),
    in_apn = document.getElementById('in_apn'),
    button_s = document.getElementById('b_save');

var scriptArgs = ["---", "ttyUSB3"];

function processText(text) {
    // Usamos una expresión regular para eliminar la parte antes de '-T ' y después de la coma.
    // Capturamos solo la parte que queremos, que es la del APN.
    const match = text.match(/-T ([^,]+),/);
    if (match && match[1]) {
        return match[1];
    } else {
        throw new Error("El formato del texto no es válido.");
    }
}

function lectura(){
    cockpit.script(read_apn, [], { superuser: "try" }).then((data, message) => {
        console.log(data);
        console.log(processText(data));
        scriptArgs[0] = processText(data);
        in_apn.value = scriptArgs[0];
    });
    cockpit.script(status_ppp0, [], { superuser: "try" }).then((data, message) => {
        //console.log(data);
        var a =parseInt(data);
        status_check(a);
    });
}

function status_check(a) {
    if (a === 1) {
       s_sta.textContent = "Disable";
       //console.log("Disable");
    } else {
       s_sta.textContent = "Enable";
       //console.log("Enable");
    }
}

function guardar_info(){
    scriptArgs[0] = in_apn.value;
    button_s.disabled = true;
    cockpit.script(start_ppp0, [scriptArgs], { superuser: "try" }).then((data,message) => {
        console.log(data);
    });
    alert(`Configuring the device to enable the mobile network in 30 seconds.`);
    setTimeout(function() {button_s.disabled = false;lectura();}, 3000);
}

lectura();
console.log(s_sta.textContent);
