var s_sta = document.getElementById('s_sta'),
    in_apn = document.getElementById('in_apn'),
    button_s = document.getElementById('b_save');

var scriptArgs = ["---", "ttyUSB3"];

function processText(cadena) {
    if (cadena || cadena.indexOf("apn is") === -1) {
        const indiceInicio = cadena.indexOf("apn is") + " apn is".length;
  	// Extraemos la subcadena desde el índice de inicio hasta el final de la cadena
	const apn = cadena.substring(indiceInicio);
  	return apn;
    } else {
        console.log("NULL");
    }
}

function lectura(){
    cockpit.script(read_apn, [], { superuser: "try" }).then((data, message) => {
        console.log(data);
        console.log(processText(data));
        scriptArgs[0] = processText(data);
        in_apn.value = scriptArgs[0];
    });
    cockpit.script(status_ppp0, [], { superuser: "try" }).then((data, message) => {
        //console.log(data);
        var a =parseInt(data);
        status_check(a);
    });
}

function status_check(a) {
    if (a === 1) {
       s_sta.textContent = "Disable";
       //console.log("Disable");
    } else {
       s_sta.textContent = "Enable";
       //console.log("Enable");
    }
}

function guardar_info(){
    scriptArgs[0] = in_apn.value;
    button_s.disabled = true;
    cockpit.script(start_ppp0, [scriptArgs], { superuser: "try" }).then((data,message) => {
        console.log(data);
    });
    alert(`Configuring the device to enable the mobile network in 30 seconds.`);
    setTimeout(function() {button_s.disabled = false;lectura();}, 3000);
}

lectura();
console.log(s_sta.textContent);
