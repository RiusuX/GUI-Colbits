document.addEventListener('DOMContentLoaded', function() {
  var in_tlsca = document.getElementById('in_tlsca'),
      in_port = document.getElementById('in_port'),
      in_server = document.getElementById('in_server');

  var filewss = cockpit.file("/home/pi/basicstation/examples/corecell/lns-ttn/tc.uri");
  var filecat = cockpit.file("/home/pi/basicstation/examples/corecell/lns-ttn/tc.trust");
  var filewss_d = cockpit.file("/home/pi/plugin-bs/tc.uri");
  var filecat_d = cockpit.file("/home/pi/plugin-bs/tc.trust");

  function lectura(filewss,filecat){
    filewss.read().then((content) => {
      if (content === null) {
        //console.log('File does not exist, check your configuration');
      } else {
        //separarURL(content);
        //console.log(content);
        var partes = content.split(':');
        //console.log(partes[2]);
        var p0 = partes[0];
        in_server.value= partes[0]+":"+partes[1];
        in_port.value=partes[2];
      }
    });
    filecat.read().then((content) => {
    if (content === null) {
      //console.log('File does not exist, check your configuration');
    } else {
      //separarURL(content);
      //console.log(content);
      in_tlsca.value = content;
    }
    });
  }

  function guardar(){
    var tcuri = in_server.value + ":" + in_port.value;
    var tctrust = in_tlsca.value
    filewss.replace(tcuri);
    filecat.replace(tctrust);
    alert("The changes were applied correctly.");
    console.log("saveeee");
  }

  //save
  document.getElementById('save_b').addEventListener('click', function() {
    guardar();
  });

  //set default
  document.getElementById('set_b').addEventListener('click', function() {
    var resultado = confirm("Are you sure about restoring factory settings?");
    if (resultado) {
      filewss_d.read().then((content) => {
        if (content === null) {
          //console.log('File does not exist, check your configuration');
        } else {
          //separarURL(content);
          filewss.replace(content);
          var partes = content.split(':');
          var p0 = partes[0];
          in_server.value= partes[0]+":"+partes[1];
          in_port.value=partes[2];
          alert("The changes were successfully applied to the wss file.");
          console.log("set_wss");
        }
      });
      filecat_d.read().then((content) => {
        if (content === null) {
          //console.log('File does not exist, check your configuration');
        } else {
          filecat.replace(content);
          in_tlsca.value = content;
          alert("The changes were successfully applied to the cat file.");
          console.log("set_cat");
        }
      });
      } else {
      set_default(filewss,filecat,guardar);
    }
  });

  lectura(filewss,filecat);
});

