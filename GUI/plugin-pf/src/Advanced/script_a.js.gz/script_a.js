var fileJSON = cockpit.file("/opt/semtech/sx1302_hal/packet_forwarder/global_conf.json", { syntax: JSON });
var fileDefault = cockpit.file("/home/pi/plugin-pf/src/Custom/default_config.json", { syntax: JSON });
var s_kai = document.getElementById('s_kai'),
    s_stat = document.getElementById('s_stat'),
    s_timeout = document.getElementById('s_timeout'),
    sd_crc = document.getElementById('sd_crc'),
    se_crc = document.getElementById('se_crc'),
    sv_crc = document.getElementById('sv_crc');
var scriptContent = `
#!/bin/bash
echo "Reiniciando el servicio"
# Comando para reiniciar el GW
sudo systemctl restart sx1302_pkt_fwd.service
`;

function lectura(){
    fileJSON.read().then((content) => {
        // Si data es nulo, significa que el archivo no existe
        if (content === null) {
            console.log('File does not exist, check your WSBRD configuration');
        } else {
            //console.log(content);
            console.log('inicinado lectura');
            filedata = JSON.parse(JSON.stringify(content));
            s_kai.value = filedata.gateway_conf.keepalive_interval;
            s_stat.value = filedata.gateway_conf.stat_interval;
            s_timeout.value = filedata.gateway_conf.push_timeout_ms;
            sd_crc.checked = filedata.gateway_conf.forward_crc_disabled;
            se_crc.checked = filedata.gateway_conf.forward_crc_error;
            sv_crc.checked = filedata.gateway_conf.forward_crc_valid;
            console.log('finalizo lectura');
        }
    });
}

function guardarInformacion(){
    fileJSON.read().then((content) => {
        // Si data es nulo, significa que el archivo no existe
        if (content === null) {
            console.log('File does not exist, check your WSBRD configuration');
        } else {
            //console.log(content);
            console.log('guardadndo');
            filedata = JSON.parse(JSON.stringify(content));
            filedata.gateway_conf.keepalive_interval = s_kai.value;
            filedata.gateway_conf.stat_interval = s_stat.value;
            filedata.gateway_conf.push_timeout_ms = s_timeout.value;
            filedata.gateway_conf.forward_crc_disabled = sd_crc.checked;
            filedata.gateway_conf.forward_crc_error = se_crc.checked;
            filedata.gateway_conf.forward_crc_valid = sv_crc.checked;
            fileJSON.replace(JSON.stringify(filedata, null, 2));
            alert("Información guardada con éxito.");
            cockpit.script(scriptContent, [], { superuser: "try" }).then((data, message) => {
                console.log("Script ejecutado exitosamente");
            })
            .catch((exception, data) => {
                console.log("Error al ejecutar el script");
            });
        }    
    });
}

function se_default(){
    fileDefault.read().then((content) => {
        // Si data es nulo, significa que el archivo no existe
        if (content === null) {
            console.log('File does not exist, check your WSBRD configuration');
        } else {
            //console.log(content);
            filedata = JSON.parse(JSON.stringify(content));
            fileJSON.replace(JSON.stringify(filedata, null, 2));
            console.log('set default');
            lectura();
            alert("Información guardada con éxito.");
            cockpit.script(scriptContent, [], { superuser: "try" }).then((data, message) => {
                console.log("Script ejecutado exitosamente");
            })
            .catch((exception, data) => {
                console.log("Error al ejecutar el script");
            });
        }
    });
}

lectura();