
var checkbox = document.getElementById('toggleCheckbox');
var textarea = document.getElementById('tex_input');
var fileJSON = cockpit.file("/opt/semtech/sx1302_hal/packet_forwarder/global_conf.json", { syntax: JSON });
var fileDefault = cockpit.file("/home/pi/plugin-pf/src/Custom/default_config.json", { syntax: JSON });

var scriptContent = `
#!/bin/bash
echo "Reiniciando el servicio"
# Comando para reiniciar el GW
sudo systemctl restart sx1302_pkt_fwd.service
`;

checkbox.checked = false;
// Agrega un evento de cambio al checkbox
checkbox.addEventListener('change', function() {
    // Si el checkbox está marcado, muestra el textarea; de lo contrario, ocúltalo
    textarea.classList.toggle('hidden', !this.checked);
});

function guardarInformacion() {
    // Obtén los valores del formulario
    var datos = document.getElementById("tex_input").value;
    var obj = JSON.parse(datos);
    fileJSON.replace(JSON.stringify(obj, null, 2));
    alert("Información guardada con éxito.");
    cockpit.script(scriptContent, [], { superuser: "try" }).then((data, message) => {
        console.log("Script ejecutado exitosamente");
    })
    .catch((exception, data) => {
        console.log("Error al ejecutar el script");
    });
    
}

function set_defaoult(){
    fileDefault.read().then((content) => {
      // Si data es nulo, significa que el archivo no existe
      if (content === null) {
        console.log('File does not exist, check your WSBRD configuration');
      } else {
        var fileData = JSON.parse(JSON.stringify(content));
        fileJSON.replace(JSON.stringify(fileData, null, 2));
        textarea.value = '';
        checkbox.checked = false;
        textarea.classList.toggle('hidden', !this.checked);
        alert("Configuracion default");
        cockpit.script(scriptContent, [], { superuser: "try" }).then((data, message) => {
            console.log("Script ejecutado exitosamente");
        })
        .catch((exception, data) => {
            console.log("Error al ejecutar el script");
        });
      }
    });
}