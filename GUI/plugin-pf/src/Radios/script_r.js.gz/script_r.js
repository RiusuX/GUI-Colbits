var fileJSON = cockpit.file("/opt/semtech/sx1302_hal/packet_forwarder/global_conf.json", { syntax: JSON });
var fileDefault = cockpit.file("/home/pi/default_config.json", { syntax: JSON });
var s_radio0 = document.getElementById('s_radio0'),
    s_radio1 = document.getElementById('s_radio1');
var se_ch0 = document.getElementById('se_ch0'),
    sr_ch0 = document.getElementById('sr_ch0'),
    sf_ch0 = document.getElementById('sf_ch0');
var se_ch1 = document.getElementById('se_ch1'),
    sr_ch1 = document.getElementById('sr_ch1'),
    sf_ch1 = document.getElementById('sf_ch1');
var se_ch2 = document.getElementById('se_ch2'),
    sr_ch2 = document.getElementById('sr_ch2'),
    sf_ch2 = document.getElementById('sf_ch2');
var se_ch3 = document.getElementById('se_ch3'),
    sr_ch3 = document.getElementById('sr_ch3'),
    sf_ch3 = document.getElementById('sf_ch3');
var se_ch4 = document.getElementById('se_ch4'),
    sr_ch4 = document.getElementById('sr_ch4'),
    sf_ch4 = document.getElementById('sf_ch4');
var se_ch5 = document.getElementById('se_ch5'),
    sr_ch5 = document.getElementById('sr_ch5'),
    sf_ch5 = document.getElementById('sf_ch5');
var se_ch6 = document.getElementById('se_ch6'),
    sr_ch6 = document.getElementById('sr_ch6'),
    sf_ch6 = document.getElementById('sf_ch6');
var se_ch7 = document.getElementById('se_ch7'),
    sr_ch7 = document.getElementById('sr_ch7'),
    sf_ch7 = document.getElementById('sf_ch7');
var se_lora = document.getElementById('se_lora'),
    sr_lora = document.getElementById('sr_lora'),
    sf_lora = document.getElementById('sf_lora'),
    sb_lora = document.getElementById('sb_lora'),
    sd_lora = document.getElementById('sd_lora');
var se_fsk = document.getElementById('se_fsk'),
    sr_fsk = document.getElementById('sr_fsk'),
    sf_fsk = document.getElementById('sf_fsk'),
    sb_fsk = document.getElementById('sb_fsk'),
    sd_fsk = document.getElementById('sd_fsk');
var scriptContent = `
#!/bin/bash
echo "Reiniciando el servicio"
# Comando para reiniciar el GW
sudo systemctl restart sx1302_pkt_fwd.service
`;


function radio_select(index){
  if (index==0){
    index = (filedata.SX130x_conf.radio_0.freq)/1000000;
  } else if (index==1){
    index = (filedata.SX130x_conf.radio_1.freq)/1000000;
  } return index;
}

function lectura(){
  fileJSON.read()
  .then((content) => {
    // Si data es nulo, significa que el archivo no existe
    if (content === null) {
        console.log('File does not exist, check your WSBRD configuration');
    } else {
        //console.log(content);
        console.log('file read');
        filedata = JSON.parse(JSON.stringify(content));
        //span RadioChannerlSetting
        s_radio0.value = (filedata.SX130x_conf.radio_0.freq)/1000000;
        s_radio1.value = (filedata.SX130x_conf.radio_1.freq)/1000000;
        //span MulyiChannerlSetting
        se_ch0.checked = filedata.SX130x_conf.chan_multiSF_0.enable;
        se_ch1.checked = filedata.SX130x_conf.chan_multiSF_1.enable;
        se_ch2.checked = filedata.SX130x_conf.chan_multiSF_2.enable;
        se_ch3.checked = filedata.SX130x_conf.chan_multiSF_3.enable;
        se_ch4.checked = filedata.SX130x_conf.chan_multiSF_4.enable;
        se_ch5.checked = filedata.SX130x_conf.chan_multiSF_5.enable;
        se_ch6.checked = filedata.SX130x_conf.chan_multiSF_6.enable;
        se_ch7.checked = filedata.SX130x_conf.chan_multiSF_7.enable;

        sr_ch0.selectedIndex = filedata.SX130x_conf.chan_multiSF_0.radio;
        sr_ch1.selectedIndex = filedata.SX130x_conf.chan_multiSF_1.radio;
        sr_ch2.selectedIndex = filedata.SX130x_conf.chan_multiSF_2.radio;
        sr_ch3.selectedIndex = filedata.SX130x_conf.chan_multiSF_3.radio;
        sr_ch4.selectedIndex = filedata.SX130x_conf.chan_multiSF_4.radio;
        sr_ch5.selectedIndex = filedata.SX130x_conf.chan_multiSF_5.radio;
        sr_ch6.selectedIndex = filedata.SX130x_conf.chan_multiSF_6.radio;

        sf_ch0.value = (radio_select(filedata.SX130x_conf.chan_multiSF_0.radio) + (filedata.SX130x_conf.chan_multiSF_0.if)/1000000).toFixed(1);
        sf_ch1.value = (radio_select(filedata.SX130x_conf.chan_multiSF_1.radio) + (filedata.SX130x_conf.chan_multiSF_1.if)/1000000).toFixed(1);
        sf_ch2.value = (radio_select(filedata.SX130x_conf.chan_multiSF_2.radio) + (filedata.SX130x_conf.chan_multiSF_2.if)/1000000).toFixed(1);
        sf_ch3.value = (radio_select(filedata.SX130x_conf.chan_multiSF_3.radio) + (filedata.SX130x_conf.chan_multiSF_3.if)/1000000).toFixed(1);
        sf_ch4.value = (radio_select(filedata.SX130x_conf.chan_multiSF_4.radio) + (filedata.SX130x_conf.chan_multiSF_4.if)/1000000).toFixed(1);
        sf_ch5.value = (radio_select(filedata.SX130x_conf.chan_multiSF_5.radio) + (filedata.SX130x_conf.chan_multiSF_5.if)/1000000).toFixed(1);
        sf_ch6.value = (radio_select(filedata.SX130x_conf.chan_multiSF_6.radio) + (filedata.SX130x_conf.chan_multiSF_6.if)/1000000).toFixed(1);
        sf_ch7.value = (radio_select(filedata.SX130x_conf.chan_multiSF_7.radio) + (filedata.SX130x_conf.chan_multiSF_7.if)/1000000).toFixed(1);
        //span loRaChannerlSetting
        se_lora.checked = filedata.SX130x_conf.chan_Lora_std.enable;
        sr_lora.selectedIndex = filedata.SX130x_conf.chan_Lora_std.radio;
        sf_lora.value = (radio_select(filedata.SX130x_conf.chan_Lora_std.radio) + (filedata.SX130x_conf.chan_Lora_std.if)/1000000).toFixed(1);
        sb_lora.value = (filedata.SX130x_conf.chan_Lora_std.bandwidth)/1000;
        sd_lora.value = filedata.SX130x_conf.chan_Lora_std.spread_factor;
        //span FSKChannelSetting
        se_fsk.checked = filedata.SX130x_conf.chan_FSK.enable;
        sr_fsk.selectedIndex = filedata.SX130x_conf.chan_FSK.radio;
        sf_fsk.value = (radio_select(filedata.SX130x_conf.chan_FSK.radio) + (filedata.SX130x_conf.chan_Lora_std.if)/1000000).toFixed(1);
        sb_fsk.value = (filedata.SX130x_conf.chan_FSK.bandwidth)/1000;
        sd_fsk.value = filedata.SX130x_conf.chan_FSK.datarate;
    }
  })
}

function guardar_info(){
    fileJSON.read().then((content) => {
        // Si data es nulo, significa que el archivo no existe
        if (content === null) {
            console.log('File does not exist, check your WSBRD configuration');
        } else {
            //console.log(content);
            console.log('guardando');
            filedata = JSON.parse(JSON.stringify(content));
            //span RadioChannerlSetting
            filedata.SX130x_conf.radio_0.freq = (s_radio0.value)*1000000;
            filedata.SX130x_conf.radio_1.freq = (s_radio1.value)*1000000;
            //span MulyiChannerlSetting
            filedata.SX130x_conf.chan_multiSF_0.enable = se_ch0.checked;
            filedata.SX130x_conf.chan_multiSF_1.enable = se_ch1.checked;
            filedata.SX130x_conf.chan_multiSF_2.enable = se_ch2.checked;
            filedata.SX130x_conf.chan_multiSF_3.enable = se_ch3.checked;
            filedata.SX130x_conf.chan_multiSF_4.enable = se_ch4.checked;
            filedata.SX130x_conf.chan_multiSF_5.enable = se_ch5.checked;
            filedata.SX130x_conf.chan_multiSF_6.enable = se_ch6.checked;
            filedata.SX130x_conf.chan_multiSF_7.enable = se_ch7.checked;

            filedata.SX130x_conf.chan_multiSF_0.radio = sr_ch0.selectedIndex;
            filedata.SX130x_conf.chan_multiSF_1.radio = sr_ch1.selectedIndex;
            filedata.SX130x_conf.chan_multiSF_2.radio = sr_ch2.selectedIndex;
            filedata.SX130x_conf.chan_multiSF_3.radio = sr_ch3.selectedIndex;
            filedata.SX130x_conf.chan_multiSF_4.radio = sr_ch4.selectedIndex;
            filedata.SX130x_conf.chan_multiSF_5.radio = sr_ch5.selectedIndex;
            filedata.SX130x_conf.chan_multiSF_6.radio = sr_ch6.selectedIndex;
            filedata.SX130x_conf.chan_multiSF_7.radio = sr_ch7.selectedIndex;

            filedata.SX130x_conf.chan_multiSF_0.if = ((sf_ch0.value)*1000000) - radio_select(filedata.SX130x_conf.chan_multiSF_0.radio);
            filedata.SX130x_conf.chan_multiSF_1.if = ((sf_ch1.value)*1000000) - radio_select(filedata.SX130x_conf.chan_multiSF_1.radio);
            filedata.SX130x_conf.chan_multiSF_2.if = ((sf_ch2.value)*1000000) - radio_select(filedata.SX130x_conf.chan_multiSF_2.radio);
            filedata.SX130x_conf.chan_multiSF_3.if = ((sf_ch3.value)*1000000) - radio_select(filedata.SX130x_conf.chan_multiSF_3.radio);
            filedata.SX130x_conf.chan_multiSF_4.if = ((sf_ch4.value)*1000000) - radio_select(filedata.SX130x_conf.chan_multiSF_4.radio);
            filedata.SX130x_conf.chan_multiSF_5.if = ((sf_ch5.value)*1000000) - radio_select(filedata.SX130x_conf.chan_multiSF_5.radio);
            filedata.SX130x_conf.chan_multiSF_6.if = ((sf_ch6.value)*1000000) - radio_select(filedata.SX130x_conf.chan_multiSF_6.radio);
            filedata.SX130x_conf.chan_multiSF_7.if = ((sf_ch7.value)*1000000) - radio_select(filedata.SX130x_conf.chan_multiSF_7.radio);
            //span loRaChannerlSetting
            filedata.SX130x_conf.chan_Lora_std.enable = se_lora.checked;
            filedata.SX130x_conf.chan_Lora_std.radio = sr_lora.selectedIndex;
            filedata.SX130x_conf.chan_Lora_std.if = (sf_lora.value)*1000000 - radio_select(filedata.SX130x_conf.chan_Lora_std.radio);
            filedata.SX130x_conf.chan_Lora_std.bandwidth = (sb_lora.value)*1000;
            filedata.SX130x_conf.chan_Lora_std.spread_factor = sd_lora.value;
            //span FSKChannelSetting
            filedata.SX130x_conf.chan_FSK.enable = se_fsk.checked;
            filedata.SX130x_conf.chan_FSK.radio = sr_fsk.selectedIndex;
            filedata.SX130x_conf.chan_Lora_std.if = (sf_fsk.value)*1000000 - radio_select(filedata.SX130x_conf.chan_FSK.radio);
            filedata.SX130x_conf.chan_FSK.bandwidth = (sb_fsk.value)*1000;
            filedata.SX130x_conf.chan_FSK.datarate = sd_fsk.value;

            fileJSON.replace(JSON.stringify(filedata, null, 2));
            console.log('finish');
            alert("Información guardada con éxito.");
            cockpit.script(scriptContent, [], { superuser: "try" }).then((data, message) => {
                console.log("Script ejecutado exitosamente");
            })
            .catch((exception, data) => {
                console.log("Error al ejecutar el script");
            });
    }
  })

}

function se_default(){
    fileDefault.read().then((content) => {
        // Si data es nulo, significa que el archivo no existe
        if (content === null) {
            console.log('File does not exist, check your WSBRD configuration');
        } else {
            //console.log(content);
            filedata = JSON.parse(JSON.stringify(content));
            fileJSON.replace(JSON.stringify(filedata, null, 2));
            console.log('set default');
            lectura();
            alert("Información guardada con éxito");
            cockpit.script(scriptContent, [], { superuser: "try" }).then((data, message) => {
                console.log("Script ejecutado exitosamente");
            })
            .catch((exception, data) => {
                console.log("Error al ejecutar el script");
            });
    }
  })
}

lectura();
